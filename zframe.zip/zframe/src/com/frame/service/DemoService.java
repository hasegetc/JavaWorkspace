package com.frame.service;

import java.util.Map;

public interface DemoService {

	public void insert(Map map);

}
