package com.sinaapp.sanrenxing.service;

import java.util.Map;

public interface DemoService {

	public void insert(Map map);

}
