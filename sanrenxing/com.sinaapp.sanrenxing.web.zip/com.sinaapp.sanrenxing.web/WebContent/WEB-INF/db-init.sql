create table student
(
  ID          NUMERIC,
  NAME        VARCHAR(100),
  GENDER      VARCHAR(1),
  AGE         NUMERIC,
  CREATE_DATE DATE,
  UPDATE_DATE DATE
);

